# Bazel nodejs Labs

This package contains experimental code which isn't at the same quality or stability standard as our main packages.

By using code in Labs, we trust that you understand:

- It might be deleted at any time
- We offer no support guarantees for using it
- Breaking changes can happen in any release
- We could release with bugs or other brokenness
- Documentation is sparse


## protobufjs_ts_library

**USAGE**

<pre>
protobufjs_ts_library(<a href="#protobufjs_ts_library-name">name</a>, <a href="#protobufjs_ts_library-deps">deps</a>, <a href="#protobufjs_ts_library-output_name">output_name</a>)
</pre>

Wraps https://github.com/dcodeIO/protobuf.js for use in Bazel.

`ts_proto_library` has identical outputs to `ts_library`, so it can be used anywhere
a `ts_library` can appear, such as in the `deps[]` of another `ts_library`.

Example:

```python
load("@npm//@bazel/typescript:index.bzl", "ts_library", "ts_proto_library")

proto_library(
    name = "car_proto",
    srcs = ["car.proto"],
)

ts_proto_library(
    name = "car",
    deps = [":car_proto"],
)

ts_library(
    name = "test_lib",
    testonly = True,
    srcs = ["car.spec.ts"],
    deps = [":car"],
)
```

Note in this example we named the `ts_proto_library` rule `car` so that the
result will be `car.d.ts`. This means our TypeScript code can just
`import {symbols} from './car'`. Use the `output_name` attribute if you want to
name the rule differently from the output file.

The JavaScript produced by protobuf.js has a runtime dependency on a support library.
Under devmode (e.g. `concatjs_devserver`, `karma_web_test_suite`) you'll need to include these scripts
in the `bootstrap` phase (before Require.js loads). You can use the label
`@npm//@bazel/labs/protobufjs:bootstrap_scripts` to reference these scripts
in the `bootstrap` attribute of `karma_web_test_suite` or `concatjs_devserver`.

To complete the example above, you could write a `karma_web_test_suite`:

```python
load("@npm//@bazel/concatjs:index.bzl", "karma_web_test_suite")

karma_web_test_suite(
    name = "test",
    deps = ["test_lib"],
    bootstrap = ["@npm//@bazel/labs/protobufjs:bootstrap_scripts"],
    browsers = [
        "@io_bazel_rules_webtesting//browsers:chromium-local",
        "@io_bazel_rules_webtesting//browsers:firefox-local",
    ],
)
```


**ATTRIBUTES**


<h4 id="protobufjs_ts_library-name">name</h4>

(*<a href="https://bazel.build/docs/build-ref.html#name">Name</a>, mandatory*): A unique name for this target.


<h4 id="protobufjs_ts_library-deps">deps</h4>

(*<a href="https://bazel.build/docs/build-ref.html#labels">List of labels</a>*): proto_library targets

Defaults to `[]`

<h4 id="protobufjs_ts_library-output_name">output_name</h4>

(*String*): Name of the resulting module, which you will import from.
            If not specified, the name will match the target's name.

Defaults to `""`



## ts_proto_library

**USAGE**

<pre>
ts_proto_library(<a href="#ts_proto_library-name">name</a>, <a href="#ts_proto_library-proto">proto</a>)
</pre>



**ATTRIBUTES**


<h4 id="ts_proto_library-name">name</h4>

(*<a href="https://bazel.build/docs/build-ref.html#name">Name</a>, mandatory*): A unique name for this target.


<h4 id="ts_proto_library-proto">proto</h4>

(*<a href="https://bazel.build/docs/build-ref.html#labels">Label</a>, mandatory*)  The dependencies of this attribute must provide: ProtoInfo




