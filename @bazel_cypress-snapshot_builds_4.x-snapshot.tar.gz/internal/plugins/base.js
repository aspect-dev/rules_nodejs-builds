module.exports = (on, config) => {
  return config;
};
