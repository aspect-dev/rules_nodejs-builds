/// <amd-module name="@bazel/karma" />
export {};
