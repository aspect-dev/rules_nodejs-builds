
# Jasmine rules for Bazel

The Jasmine rules run tests under the Jasmine framework with Bazel.

## Installation

Add the `@bazel/jasmine` npm package to your `devDependencies` in `package.json`.


## jasmine_node_test

**USAGE**

<pre>
jasmine_node_test(<a href="#jasmine_node_test-name">name</a>, <a href="#jasmine_node_test-srcs">srcs</a>, <a href="#jasmine_node_test-data">data</a>, <a href="#jasmine_node_test-deps">deps</a>, <a href="#jasmine_node_test-expected_exit_code">expected_exit_code</a>, <a href="#jasmine_node_test-tags">tags</a>, <a href="#jasmine_node_test-config_file">config_file</a>, <a href="#jasmine_node_test-use_direct_specs">use_direct_specs</a>,
                  <a href="#jasmine_node_test-jasmine">jasmine</a>, <a href="#jasmine_node_test-jasmine_entry_point">jasmine_entry_point</a>, <a href="#jasmine_node_test-kwargs">kwargs</a>)
</pre>

Runs tests in NodeJS using the Jasmine test runner.

Detailed XML test results are found in the standard `bazel-testlogs`
directory. This may be symlinked in your workspace.
See https://docs.bazel.build/versions/master/output_directories.html

To debug the test, see debugging notes in `nodejs_test`.


**PARAMETERS**


<h4 id="jasmine_node_test-name">name</h4>

Name of the resulting label



<h4 id="jasmine_node_test-srcs">srcs</h4>

JavaScript source files containing Jasmine specs

Defaults to `[]`

<h4 id="jasmine_node_test-data">data</h4>

Runtime dependencies which will be loaded while the test executes

Defaults to `[]`

<h4 id="jasmine_node_test-deps">deps</h4>

Other targets which produce JavaScript, such as ts_library

Defaults to `[]`

<h4 id="jasmine_node_test-expected_exit_code">expected_exit_code</h4>

The expected exit code for the test.

Defaults to `0`

<h4 id="jasmine_node_test-tags">tags</h4>

Bazel tags applied to test

Defaults to `[]`

<h4 id="jasmine_node_test-config_file">config_file</h4>

(experimental) label of a file containing Jasmine JSON config.

Note that not all configuration options are honored, and
we expect some strange feature interations.
For example, the filter for which files are instrumented for
code coverage doesn't understand the spec_files setting in the config.

See https://jasmine.github.io/setup/nodejs.html#configuration

Defaults to `None`

<h4 id="jasmine_node_test-use_direct_specs">use_direct_specs</h4>

Limits the list of specs added to the execution (test suite) to direct sources.

Note that this is a bug fix opt-in flag, which will be the default
behavior in the next major release.

More info: https://github.com/bazelbuild/rules_nodejs/pull/2576

Defaults to `None`

<h4 id="jasmine_node_test-jasmine">jasmine</h4>

A label providing the `@bazel/jasmine` npm dependency.

Defaults to `"//@bazel/jasmine"`

<h4 id="jasmine_node_test-jasmine_entry_point">jasmine_entry_point</h4>

A label providing the `@bazel/jasmine` entry point.

Defaults to `"//:node_modules/@bazel/jasmine/jasmine_runner.js"`

<h4 id="jasmine_node_test-kwargs">kwargs</h4>

Remaining arguments are passed to the test rule




